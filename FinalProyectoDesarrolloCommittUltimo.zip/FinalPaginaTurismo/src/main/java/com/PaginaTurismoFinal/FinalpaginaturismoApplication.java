package com.PaginaTurismoFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalpaginaturismoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalpaginaturismoApplication.class, args);
	}

}
