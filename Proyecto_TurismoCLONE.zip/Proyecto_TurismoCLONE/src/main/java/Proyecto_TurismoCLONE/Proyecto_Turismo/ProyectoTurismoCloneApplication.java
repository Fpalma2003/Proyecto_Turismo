package Proyecto_TurismoCLONE.Proyecto_Turismo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoTurismoCloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoTurismoCloneApplication.class, args);
	}

}
