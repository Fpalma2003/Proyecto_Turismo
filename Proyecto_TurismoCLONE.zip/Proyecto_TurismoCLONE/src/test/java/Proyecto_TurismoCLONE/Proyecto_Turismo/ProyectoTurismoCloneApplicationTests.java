package Proyecto_TurismoCLONE.Proyecto_Turismo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoTurismoCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
