/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.PaginaTurismoFinal.Repository;

import com.PaginaTurismoFinal.entity.RestaurantesReserva;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author Andra Mckenzie Araya
 */
public interface RestaurantesReservaRepository extends CrudRepository<RestaurantesReserva, Long> {

}
