/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Proyecto_TurismoCLONE.Proyecto_Turismo.service;

import Proyecto_TurismoCLONE.Proyecto_Turismo.entity.Audiencia;
import Proyecto_TurismoCLONE.Proyecto_Turismo.entity.Restaurante;
import java.util.List;

/**
 *
 * @author ala11
 */
public interface IRestauranteService {
    public List<Restaurante> listRest();
}
